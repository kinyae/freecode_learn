This folder contains a list of json files representing the name
of revisioned client files. It is empty due to the fact that the
files are generated at runtime and their content is determined by
the content of the files they are derived from.

Since the build process is not exactly the same on every machine,
these files are not tracked in github otherwise conflicts arise when
building on our servers.
