exports.addPlaceholderImage = function addPlaceholderImage(name) {
  return `https://example.com/${name}.png`;
};
