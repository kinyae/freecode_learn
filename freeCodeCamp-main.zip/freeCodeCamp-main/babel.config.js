module.exports = { babelrcRoots: ['./api-server', './client'] };
