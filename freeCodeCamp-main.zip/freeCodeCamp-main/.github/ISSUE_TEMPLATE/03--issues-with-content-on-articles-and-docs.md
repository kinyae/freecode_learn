---
name: 'Report issues with content on /news, guide articles or documentation'
about: Report issues with content on a specific article, like broken links, typos, missing parts, etc.
title: ''
labels: 'type: bug, status: waiting triage'
assignees: ''

---

<!--
NOTE: If you want to become an author on freeCodeCamp, you can find everything here: https://www.freecodecamp.org/news/developer-news-style-guide/
-->

**Describe your problem and how to reproduce it:**


**Add a Link to the page with the problem:**


**Recommended fix, suggestions (how would you update it?):**


**If possible, add a screenshot here (you can drag and drop, png, jpg, gif, etc. in this box):**
