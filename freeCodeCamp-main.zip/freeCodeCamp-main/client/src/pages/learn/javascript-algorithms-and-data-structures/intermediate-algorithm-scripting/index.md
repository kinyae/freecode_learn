---
title: Introduction to the Intermediate Algorithm Scripting Challenges
block: Intermediate Algorithm Scripting
superBlock: JavaScript Algorithms and Data Structures
---
## Introduction to the Intermediate Algorithm Scripting Challenges

The following challenges are part of FCC's Intermediate Algorithm Scripting Challenges. These should prepare you to complete the final challenges for the JavaScript Algorithms And Data Structures Certification.

These challenges will allow you to test how much you have learned and which parts you may need to review again before starting the projects.

With that being said-

Have fun and remember to use the [Read-Search-Ask](https://forum.freecodecamp.org/t/how-to-get-help-when-you-are-stuck-coding/19514) method if you get stuck.

Good Luck!
