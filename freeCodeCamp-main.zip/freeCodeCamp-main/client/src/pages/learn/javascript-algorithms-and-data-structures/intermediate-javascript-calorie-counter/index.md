---
title: Introduction to the Intermediate JavaScript Calorie Counter
block: Intermediate JavaScript Calorie Counter
superBlock: JavaScript Algorithms and Data Structures
isBeta: true
---
## Introduction to the Intermediate JavaScript Calorie Counter

This is a stub for the new project-based curriculum.