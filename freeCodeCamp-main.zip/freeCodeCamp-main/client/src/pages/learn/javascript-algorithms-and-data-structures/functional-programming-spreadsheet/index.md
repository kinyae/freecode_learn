---
title: Introduction to the Functional Programming Spreadsheet
block: Functional Programming Spreadsheet
superBlock: JavaScript Algorithms and Data Structures
isBeta: true
---

## Introduction to the JavaScript Spreadsheet

This is a test for the new project-based curriculum.
