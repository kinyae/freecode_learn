---
title: Introduction to the Rosetta Code Problems
block: Rosetta Code
superBlock: Coding Interview Prep
---
## Introduction to the Rosetta Code Problems

[The Rosetta Code](https://rosettacode.org) is a list of programming challenges which will help you build your programming skills.
>"The idea is to present solutions to the same task in as many different languages as possible, to demonstrate how languages are similar and different, and to aid a person with a grounding in one approach to a problem in learning another." - _Homepage of the Rosetta Code site_
