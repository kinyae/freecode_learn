---
title: Introduction to the Coding Interview Data Structure Questions
block: Data Structures
superBlock: Coding Interview Prep
---
## Introduction to the Coding Interview Data Structure Questions

These excercises are meant to help you deal with large or complex data by using many different data types other than your standard objects or arrays. 
