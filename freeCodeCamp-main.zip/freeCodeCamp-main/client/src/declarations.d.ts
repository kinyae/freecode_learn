// eslint-disable-next-line import/unambiguous
declare module '@freecodecamp/react-bootstrap';
