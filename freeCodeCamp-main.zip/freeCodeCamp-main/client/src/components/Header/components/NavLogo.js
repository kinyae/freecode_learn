import React from 'react';
import FreeCodeCampLogo from '../../../assets/icons/FreeCodeCampLogo';

function NavLogo() {
  return <FreeCodeCampLogo />;
}

NavLogo.displayName = 'NavLogo';
export default NavLogo;
